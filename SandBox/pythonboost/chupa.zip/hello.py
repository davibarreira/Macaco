import hello

print(hello.greet())
